## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(DBI)){install.packages("DBI")}
if(!require(DBI)){install.packages("DBI")}
if(!require(RMySQL)){install.packages("RMySQL")}
if(!require(RMySQL)){install.packages("RMySQL")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("DBI")
isPackageLoaded("RMySQL")


edx_app <- dbConnect(MySQL(),user="root", password="swingDb123", dbname="edxapp", host="edraak-reports-read-replica.cakypgia33fn.eu-west-1.rds.amazonaws.com")

dbGetQuery(edx_app, "SET NAMES utf8")
charset <- dbGetQuery(edx_app, "show variables like 'character_set%'")
#https://github.com/rstats-db/RMySQL/issues/2

dbb <- dbListTables(edx_app)

aff0 <- dbReadTable(edx_app,"auth_userprofile")
write.csv(aff0,"dataset/01_auth_userprofile.csv")
rm(aff0)

aff1 <- dbReadTable(edx_app,"auth_user")
write.csv(aff1,"dataset/02_auth_user.csv")
rm(aff1)
aff2 <- dbReadTable(edx_app,"student_courseenrollment")
write.csv(aff2,"dataset/03_student_courseenrollment.csv")
rm(aff2)
aff3 <- dbReadTable(edx_app,"courseware_studentmodule")
write.csv(aff3,"dataset/04_courseware_studentmodule.csv")
rm(aff3)
dbDisconnect(edx_app)


mrkt_site <- dbConnect(MySQL(),user="root", password="swingDb123", dbname="marketingsite", host="marketing-read-replica.cakypgia33fn.eu-west-1.rds.amazonaws.com")
dbd <- dbListTables(mrkt_site)

mktcours <- dbReadTable(mrkt_site,"marketing_course")
write.csv(mktcours,"dataset/05_mktcours.csv")
rm(mktcours)

mktcatg <- dbReadTable(mrkt_site,"marketing_coursecategory")
write.csv(mktcatg,"dataset/06_mktcatg.csv")
rm(mktcatg)
dbDisconnect(mrkt_site)
if("package:RMySQL" %in% search()) detach("package:RMySQL", unload=TRUE)
if("package:DBI" %in% search()) detach("package:DBI", unload=TRUE) 
rm(dbb, dbd, dbGetQuery, charset, edx_app, mrkt_site)
