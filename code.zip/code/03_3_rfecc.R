## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")


courseware_studentmodule <- read_csv("dataset/04_courseware_studentmodule.csv")
sc <- courseware_studentmodule[complete.cases(courseware_studentmodule[,c(3,5,8,9,12)]),]
courses <- read_csv("tmp/courses.csv")
sc <- subset(sc, course_id %in% courses$id)
rm(courseware_studentmodule)


#### filter data to recent 18 month #######
if(!require(lubridate)){install.packages("lubridate")}
if(!require(lubridate)){install.packages("lubridate")}
isPackageLoaded("lubridate")

sc$modified <- as.POSIXlt(sc$modified)
today <- as.POSIXlt(Sys.Date())
date1 <- today
date1$mday <- date1$mday + 45
date2 <- date1
date2$mday <- date1$mday - 546
sc <- sc[sc$modified <= date1 & sc$modified >= date2, ]
sum(unique(sc$student_id))

### Recency #######
pdt <- parse_date_time(sc$modified, "ymd_HMS")
DATA = data.frame((c(pdt)))
names(DATA)[1] = "V1"
date = as.Date(DATA$V1, format="%Y-%m-%d")
nn <- date-max(date)
xyz <- cbind(sc, date, nn)
rm(sc)

xyz$nn_days <- xyz$nn
xyz$nn_weeks <- xyz$nn_days/7

write.csv(xyz, "tmp/xyz.csv")
rm(xyz, pdt, DATA, date, nn)
xyz <- read_csv("tmp/xyz.csv")


if(!require(sqldf)){install.packages("sqldf")}
if(!require(sqldf)){install.packages("sqldf")}
isPackageLoaded("sqldf")

recency = sqldf("SELECT student_id,
                MAX(nn_weeks) AS 'recency'
                FROM xyz GROUP BY 1")
write.csv(recency, "tmp/recency.csv")
##done recency 

### Frequency ####
if(!require(plyr)){install.packages("plyr")}
if(!require(plyr)){install.packages("plyr")}
isPackageLoaded("plyr")

sc <- xyz
pdt <- parse_date_time(sc$modified, "ymd_HMS")
DATA = data.frame((c(pdt)))
names(DATA)[1] = "V1"
date = as.Date(DATA$V1, format="%Y-%m-%d")
nn_days2 <- date-max(date)
xyz <- cbind(sc, nn_days2)
rm(sc)
write.csv(xyz, "tmp/xyz_f_tmp.csv")
xyz <- read_csv("tmp/xyz_f_tmp.csv")
xyz$nn_days2 <- as.numeric(xyz$nn_days2)

distinct_days = sqldf("SELECT student_id,
                      count(DISTINCT nn_days2) AS 'number_of_distinct_days'
                      FROM xyz GROUP BY student_id")

duration = sqldf("SELECT student_id, min(nn_days2) AS duration
                 FROM xyz GROUP BY student_id
                 ")
eduration <- duration$duration
eduration <- replace(as.numeric(eduration), eduration==0, -1)

duration <- cbind(duration, eduration)
frequency <- full_join(distinct_days, duration,
                       by = c("student_id" = "student_id"))

for (ifreq in 1:nrow(frequency)) {
      frequency$frequency[ifreq] <- as.numeric(-1*(frequency$number_of_distinct_days[ifreq])+1)/(frequency$eduration[ifreq]) 
}

write.csv(frequency, "tmp/frequency.csv")
rm(pdt, DATA, date, nn_days2, distinct_days, duration, eduration)



##done Frequency

### Engagement ####
sc <- xyz
rm(xyz)
engagement = sqldf("select module_type, student_id, course_id, Count(module_type)
                   from sc
                   group by module_type, student_id, course_id 
                   ")

names(engagement)[4] = "modules_count"
max_engagement = sqldf("SELECT course_id, module_type, MAX(modules_count)
                       FROM engagement 
                       GROUP BY course_id, module_type
                       ")
names(max_engagement)[3] = "max_modules"

#engagement_ration_for_each_module_inside_each_course
total <- merge(max_engagement, engagement, by=c("course_id","module_type"))
total$eng_ration <- (total$modules_count/total$max_modules)*100

write.csv(total, "tmp/total.csv")
rm(max_engagement, engagement)
total <- read_csv("tmp/total.csv")

#engagement_ration_for_each_course
course_eng_ratio = sqldf("SELECT student_id, course_id, (SUM(eng_ration)/COUNT(eng_ration*100)) AS course_eng_ratio 
                         FROM total 
                         GROUP BY student_id, course_id
                         ")


learner_eng_ratio_mini = sqldf("SELECT student_id, course_id, (SUM(course_eng_ratio)/COUNT(course_eng_ratio*100)) AS learner_eng_ratio 
                               FROM course_eng_ratio 
                               GROUP BY student_id
                               ")

##Add grades
grades <- read_csv("dataset/grades.csv")

## selecting courses !
mapping <- read_csv("dataset/mapping_course_id_and_certificates_files.csv")
mapping <- mapping[complete.cases(mapping[,"source_csv_files"]),]
grades <- subset(grades, Source %in% mapping$source_csv_files)
write.csv(sgrades, "tmp/sgrades.csv")

grades <- subset(grades, grade>= 0 & grade <= 1)
learner_grade_ratio = sqldf("SELECT id, Source, (SUM(grade)/COUNT(grade*100))*100 AS learner_grade_ratio 
                            FROM grades 
                            GROUP BY id
                            ")


x <- as.data.frame(append(learner_eng_ratio_mini$student_id, learner_grade_ratio$id))
x2 <- as.data.frame(append(learner_eng_ratio_mini$learner_eng_ratio, learner_grade_ratio$learner_grade_ratio))

learner_eng_ratio <- cbind(x,x2)

names(learner_eng_ratio)[1] = "student_id"
names(learner_eng_ratio)[2] = "eng_ratio"
learner_eng_ratio = sqldf("SELECT student_id, (SUM(eng_ratio)/COUNT(eng_ratio*100)) AS learner_eng_ratio 
                          FROM learner_eng_ratio 
                          GROUP BY student_id
                          ")

write.csv(learner_eng_ratio, "tmp/learner_eng_ratio.csv")
rm(total, course_eng_ratio, learner_eng_ratio_mini, grades, mapping, x, x2, learner_eng_ratio)

##### Done Engagement !


### count_of_courses #####

coursenroll <- read_csv("dataset/03_student_courseenrollment.csv")

count_of_coursenroll = sqldf("select user_id, Count(course_id)
                             from coursenroll
                             group by user_id 
                             ")

names(count_of_coursenroll)[2] = "count_of_coursenroll"
write.csv(count_of_coursenroll, "tmp/count_of_coursenroll.csv")
rm(coursenroll, xyz)
num_courses = 74
count_of_coursenroll <- subset(count_of_coursenroll, count_of_coursenroll <= num_courses)


write.csv(count_of_coursenroll, "tmp/count_of_coursenroll.csv")
rm(num_courses)

### Done | count_of_courses


### count_of_certificates #####
grades <- read_csv("tmp/grades.csv")
learner_course_certificate <- grades[complete.cases(grades[,c("Certificate.Eligible", "id")]),]
learner_have_certificate <- subset(learner_course_certificate, Certificate.Eligible=="Y")
write.csv(learner_have_certificate, "tmp/learner_have_certificate.csv")

learner_course_certificate <- read_csv("tmp/learner_have_certificate.csv")
count_of_certificates = sqldf("select id, Count(id) as count_of_certificates
                              from learner_have_certificate
                              group by id 
                              ")

write.csv(count_of_certificates, "tmp/count_of_certificates.csv")
rm(grades, learner_course_certificate, learner_have_certificate)


##### combine data into one table (RFECC) recenct learning activity, frequency, engagement, count of courses, count of certificates ####
if(!require(dplyr)){install.packages("dplyr")}
if(!require(dplyr)){install.packages("dplyr")}
isPackageLoaded("plyr")

b1 <- full_join(recency, frequency, by = c("id" = "student_id"))
b2 <- full_join(b1, learner_eng_ratio, by = c("id" = "student_id"), copy = TRUE)
b3 <- full_join(b2, count_of_coursenroll, by = c("id" = "user_id"), copy = TRUE)
b4 <- full_join(b3, count_of_certificates, by = c("id" = "id"), copy = TRUE)
rfecc <- b4
rm(b1,b2,b3,b4)
rm(recent_login, recenfreq, learner_eng_ratio, count_of_certificates, count_of_coursenroll)
write.csv(rfecc, "tmp/rfecc.csv")




###### End #####

