library(readr)

demograph1 <- subset(xxi, lvl1==1)
write.csv(demograph1, "1/demograph1.csv")


#1.0 unverified
demo1unverf <- subset(demograph1, lvl2==0)
write.csv(demo1unverf, "1/1.0.csv")


#1.1 verified
demo1verf <- subset(demograph1, lvl2==1)
write.csv(demo1verf, "1/1.1.csv")



#1.0.0 unverified NEW
demo1unverfNew <- subset(demo1unverf, lvl3==0)
write.csv(demo1unverfNew, "1/1.0.0.csv")


#1.0.1 unverified Regular
demo1unverfRegular <- subset(demo1unverf, lvl3==1)
write.csv(demo1unverfRegular, "1/1.0.1.csv")



#1.1.0 verified NEW
demo1verfNew <- subset(demo1verf, lvl3==0)
write.csv(demo1verfNew, "1/1.1.0.csv")

#1.1.1 verified Regular
demo1verfRegular <- subset(demo1verf, lvl3==1)
write.csv(demo1verfRegular, "1/1.1.1.csv")



####### 1st step

#1.1.1.1 verified Regular FREEZE
demo1verfRegularFrz <- subset(demo1verfRegular, lvl4==1)
write.csv(demo1verfRegularFrz, "1/1.1.1.1.csv")

#1.1.1.2 verified Regular COLD
demo1verfRegularCold <- subset(demo1verfRegular, lvl4==2)
write.csv(demo1verfRegularCold, "1/1.1.1.2.csv")

#1.1.1.3 verified Regular WARM
demo1verfRegularWrm <- subset(demo1verfRegular, lvl4==3)
write.csv(demo1verfRegularWrm, "1/1.1.1.3.csv")

#1.1.1.4 verified Regular HOT
demo1verfRegularHot <- subset(demo1verfRegular, lvl4==4)
write.csv(demo1verfRegularHot, "1/1.1.1.4.csv")



####### 2nd step 

#1.1.1.1.1 verified Regular FREEZE low
demo1verfRegularFrzLow <- subset(demo1verfRegularFrz, lvl5==1)
write.csv(demo1verfRegularFrzLow, "1/1.1.1.1.1.csv")

#1.1.1.1.2 verified Regular FREEZE mid-low
demo1verfRegularFrzMidLow <- subset(demo1verfRegularFrz, lvl5==2)
write.csv(demo1verfRegularFrzMidLow, "1/1.1.1.1.2.csv")

#1.1.1.1.3 verified Regular FREEZE mid-high
demo1verfRegularFrzHighMid <- subset(demo1verfRegularFrz, lvl5==3)
write.csv(demo1verfRegularFrzHighMid, "1/1.1.1.1.3.csv")

#1.1.1.1.4 verified Regular FREEZE high
demo1verfRegularFrzHigh <- subset(demo1verfRegularFrz, lvl5==4)
write.csv(demo1verfRegularFrzHigh, "1/1.1.1.1.4.csv")




#1.1.1.2.1 verified Regular COLD low
demo1verfRegularColdLow <- subset(demo1verfRegularCold, lvl5==1)
write.csv(demo1verfRegularColdLow, "1/1.1.1.2.1.csv")

#1.1.1.2.2 verified Regular COLD mid-low
demo1verfRegularColdMidLow <- subset(demo1verfRegularCold, lvl5==2)
write.csv(demo1verfRegularColdMidLow, "1/1.1.1.2.2.csv")

#1.1.1.2.3 verified Regular COLD high-mid
demo1verfRegularColdHighMid <- subset(demo1verfRegularCold, lvl5==3)
write.csv(demo1verfRegularColdHighMid, "1/1.1.1.2.3.csv")

#1.1.1.2.4 verified Regular COLD high
demo1verfRegularColdHigh <- subset(demo1verfRegularCold, lvl5==4)
write.csv(demo1verfRegularColdHigh, "1/1.1.1.2.4.csv")




#1.1.1.3.1 verified Regular WARM low
demo1verfRegularWrmLow <- subset(demo1verfRegularWrm, lvl5==1)
write.csv(demo1verfRegularWrmLow, "1/1.1.1.3.1.csv")

#1.1.1.3.2 verified Regular WARM mid-low
demo1verfRegularWrmMidLow <- subset(demo1verfRegularWrm, lvl5==2)
write.csv(demo1verfRegularWrmMidLow, "1/1.1.1.3.2.csv")

#1.1.1.3.3 verified Regular WARM high-mid
demo1verfRegularWrmHighMid <- subset(demo1verfRegularWrm, lvl5==3)
write.csv(demo1verfRegularWrmHighMid, "1/1.1.1.3.3.csv")

#1.1.1.3.4 verified Regular WARM high
demo1verfRegularWrmHigh <- subset(demo1verfRegularWrm, lvl5==4)
write.csv(demo1verfRegularWrmHigh, "1/1.1.1.3.4.csv")



#1.1.1.4.1 verified Regular HOT low
demo1verfRegularHotLow <- subset(demo1verfRegularHot, lvl5==1)
write.csv(demo1verfRegularHotLow, "1/1.1.1.4.1.csv")

#1.1.1.4.2 verified Regular HOT mid-low
demo1verfRegularHotMidLow <- subset(demo1verfRegularHot, lvl5==2)
write.csv(demo1verfRegularHotMidLow, "1/1.1.1.4.2.csv")

#1.1.1.4.3 verified Regular HOT high-mid
demo1verfRegularHotMidHighMid <- subset(demo1verfRegularHot, lvl5==3)
write.csv(demo1verfRegularHotMidHighMid, "1/1.1.1.4.3.csv")

#1.1.1.4.4 verified Regular HOT high
demo1verfRegularHotMidHigh <- subset(demo1verfRegularHot, lvl5==4)
write.csv(demo1verfRegularHotMidHigh, "1/1.1.1.4.4.csv")

