## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")


### chk transformation_demographics first

labels <- read_csv("tmp/elmagic.csv")
xi1 <- subset(labels, labels=="1")
xi2 <- subset(labels, labels=="2")
xi3 <- subset(labels, labels=="3")
xi4 <- subset(labels, labels=="4")
xi5 <- subset(labels, labels=="5")

xi <- rbind(xi1, xi2, xi3, xi4, xi5)
xi <- as.data.frame(xi)
xi$user_id <- as.numeric(xi$user_id)
xx <- merge(shamlx, xi, by="user_id", all.y = TRUE)
rm(xi1, xi2, xi3, xi4, xi5, xi)

s1 <- subset(xx, labels.x=="1")
s2 <- subset(xx, labels.x=="2")
s3 <- subset(xx, labels.x=="3")
s4 <- subset(xx, labels.x=="4")
s5 <- subset(xx, labels.x=="5")

s1 = s1[sample(nrow(s1), 8000, replace = F), ]
s2 = s2[sample(nrow(s2), 8000, replace = F), ]
s3 = s3[sample(nrow(s3), 8000, replace = F), ]
s4 = s4[sample(nrow(s4), 8000, replace = F), ]
s5 = s5[sample(nrow(s5), 8000, replace = F), ]

train <- rbind(s1, s2, s3, s4, s5)
data <- rbind(train, xx)
rm(s1, s2, s3, s4, s5)

test <- labels
test <- test[, c("gndr", "age_ncategory", "loe", "refugees", "labels")]
learndata <- train[, c("gndr", "age_ncategory", "loe", "refugees", "labels")]

data <- rbind(learndata, test)
sub <- c(sample(1:40000, 40000))
datasets001 <- as.data.frame(data[,c(1:6)])
datasets001$labels <- as.factor(datasets001$labels)


if(!require(adabag)){install.packages("adabag")}
if(!require(adabag)){install.packages("adabag")}
# chk pkgs loaded successfully
isPackageLoaded("adabag")

data.bagging <- bagging(labels ~ ., data=datasets001[sub,], mfinal=800)
data1.predbagging <- predict.bagging(data.bagging, newdata=datasets001[,], newmfinal = 200)
v <- cbind(datasets001, data1.predbagging$class)
dmogrf_clsf_summary <- summary(data.bagging)

mbv <- v[-c(1:40000),]
I <- cbind(labels, mbv$class)

if(!require(data.table)){install.packages("data.table")}
if(!require(data.table)){install.packages("data.table")}
# chk pkgs loaded successfully
isPackageLoaded("data.table")

I$X41 <- with(I, ifelse(labels=="", class, labels))
write.csv("tmp/I.csv")


