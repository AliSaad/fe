# Import data
## Load learners profile data
# clean learners profile data
# demographics segmentations
# RFECC
# pull demographics and RFECC in one table
## transformation_demographics first
# classification for demographics
# classification for RFECC (value)
# pull everything together
# export data
# save history from data
# save report


