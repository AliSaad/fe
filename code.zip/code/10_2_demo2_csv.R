library(readr)

demograph2 <- subset(xxi, lvl1==2)
write.csv(demograph2, "2/demograph2.csv")


#2.0 unverified
demo2unverf <- subset(demograph2, lvl2==0)
write.csv(demo2unverf, "2/2.0.csv")


#2.1 verified
demo2verf <- subset(demograph2, lvl2==1)
write.csv(demo2verf, "2/2.1.csv")



#2.0.0 unverified NEW
demo2unverfNew <- subset(demo2unverf, lvl3==0)
write.csv(demo2unverfNew, "2/2.0.0.csv")


#2.0.1 unverified Regular
demo2unverfRegular <- subset(demo2unverf, lvl3==1)
write.csv(demo2unverfRegular, "2/2.0.1.csv")



#2.1.0 verified NEW
demo2verfNew <- subset(demo2verf, lvl3==0)
write.csv(demo2verfNew, "2/2.1.0.csv")

#2.1.1 verified Regular
demo2verfRegular <- subset(demo2verf, lvl3==1)
write.csv(demo2verfRegular, "2/2.1.1.csv")



####### 1st step

#2.1.1.1 verified Regular FREEZE
demo2verfRegularFrz <- subset(demo2verfRegular, lvl4==1)
write.csv(demo2verfRegularFrz, "2/2.1.1.1.csv")

#2.1.1.2 verified Regular COLD
demo2verfRegularCold <- subset(demo2verfRegular, lvl4==2)
write.csv(demo2verfRegularCold, "2/2.1.1.2.csv")

#2.1.1.3 verified Regular WARM
demo2verfRegularWrm <- subset(demo2verfRegular, lvl4==3)
write.csv(demo2verfRegularWrm, "2/2.1.1.3.csv")

#2.1.1.4 verified Regular HOT
demo2verfRegularHot <- subset(demo2verfRegular, lvl4==4)
write.csv(demo2verfRegularHot, "2/2.1.1.4.csv")



####### 2nd step 

#2.1.1.1.1 verified Regular FREEZE low
demo2verfRegularFrzLow <- subset(demo2verfRegularFrz, lvl5==1)
write.csv(demo2verfRegularFrzLow, "2/2.1.1.1.1.csv")

#2.1.1.1.2 verified Regular FREEZE mid-low
demo2verfRegularFrzMidLow <- subset(demo2verfRegularFrz, lvl5==2)
write.csv(demo2verfRegularFrzMidLow, "2/2.1.1.1.2.csv")

#2.1.1.1.3 verified Regular FREEZE mid-high
demo2verfRegularFrzHighMid <- subset(demo2verfRegularFrz, lvl5==3)
write.csv(demo2verfRegularFrzHighMid, "2/2.1.1.1.3.csv")

#2.1.1.1.4 verified Regular FREEZE high
demo2verfRegularFrzHigh <- subset(demo2verfRegularFrz, lvl5==4)
write.csv(demo2verfRegularFrzHigh, "2/2.1.1.1.4.csv")




#2.1.1.2.1 verified Regular COLD low
demo2verfRegularColdLow <- subset(demo2verfRegularCold, lvl5==1)
write.csv(demo2verfRegularColdLow, "2/2.1.1.2.1.csv")

#2.1.1.2.2 verified Regular COLD mid-low
demo2verfRegularColdMidLow <- subset(demo2verfRegularCold, lvl5==2)
write.csv(demo2verfRegularColdMidLow, "2/2.1.1.2.2.csv")

#2.1.1.2.3 verified Regular COLD high-mid
demo2verfRegularColdHighMid <- subset(demo2verfRegularCold, lvl5==3)
write.csv(demo2verfRegularColdHighMid, "2/2.1.1.2.3.csv")

#2.1.1.2.4 verified Regular COLD high
demo2verfRegularColdHigh <- subset(demo2verfRegularCold, lvl5==4)
write.csv(demo2verfRegularColdHigh, "2/2.1.1.2.4.csv")




#2.1.1.3.1 verified Regular WARM low
demo2verfRegularWrmLow <- subset(demo2verfRegularWrm, lvl5==1)
write.csv(demo2verfRegularWrmLow, "2/2.1.1.3.1.csv")

#2.1.1.3.2 verified Regular WARM mid-low
demo2verfRegularWrmMidLow <- subset(demo2verfRegularWrm, lvl5==2)
write.csv(demo2verfRegularWrmMidLow, "2/2.1.1.3.2.csv")

#2.1.1.3.3 verified Regular WARM high-mid
demo2verfRegularWrmHighMid <- subset(demo2verfRegularWrm, lvl5==3)
write.csv(demo2verfRegularWrmHighMid, "2/2.1.1.3.3.csv")

#2.1.1.3.4 verified Regular WARM high
demo2verfRegularWrmHigh <- subset(demo2verfRegularWrm, lvl5==4)
write.csv(demo2verfRegularWrmHigh, "2/2.1.1.3.4.csv")



#2.1.1.4.1 verified Regular HOT low
demo2verfRegularHotLow <- subset(demo2verfRegularHot, lvl5==1)
write.csv(demo2verfRegularHotLow, "2/2.1.1.4.1.csv")

#2.1.1.4.2 verified Regular HOT mid-low
demo2verfRegularHotMidLow <- subset(demo2verfRegularHot, lvl5==2)
write.csv(demo2verfRegularHotMidLow, "2/2.1.1.4.2.csv")

#2.1.1.4.3 verified Regular HOT high-mid
demo2verfRegularHotMidHighMid <- subset(demo2verfRegularHot, lvl5==3)
write.csv(demo2verfRegularHotMidHighMid, "2/2.1.1.4.3.csv")

#2.1.1.4.4 verified Regular HOT high
demo2verfRegularHotMidHigh <- subset(demo2verfRegularHot, lvl5==4)
write.csv(demo2verfRegularHotMidHigh, "2/2.1.1.4.4.csv")

