library(readr)

demograph3 <- subset(xxi, lvl1==3)
write.csv(demograph3, "3/demograph3.csv")


#3.0 unverified
demo3unverf <- subset(demograph3, lvl2==0)
write.csv(demo3unverf, "3/3.0.csv")


#3.1 verified
demo3verf <- subset(demograph3, lvl2==1)
write.csv(demo3verf, "3/3.1.csv")



#3.0.0 unverified NEW
demo3unverfNew <- subset(demo3unverf, lvl3==0)
write.csv(demo3unverfNew, "3/3.0.0.csv")


#3.0.1 unverified Regular
demo3unverfRegular <- subset(demo3unverf, lvl3==1)
write.csv(demo3unverfRegular, "3/3.0.1.csv")



#3.1.0 verified NEW
demo3verfNew <- subset(demo3verf, lvl3==0)
write.csv(demo3verfNew, "3/3.1.0.csv")

#3.1.1 verified Regular
demo3verfRegular <- subset(demo3verf, lvl3==1)
write.csv(demo3verfRegular, "3/3.1.1.csv")



####### 1st step

#3.1.1.1 verified Regular FREEZE
demo3verfRegularFrz <- subset(demo3verfRegular, lvl4==1)
write.csv(demo3verfRegularFrz, "3/3.1.1.1.csv")

#3.1.1.2 verified Regular COLD
demo3verfRegularCold <- subset(demo3verfRegular, lvl4==2)
write.csv(demo3verfRegularCold, "3/3.1.1.2.csv")

#3.1.1.3 verified Regular WARM
demo3verfRegularWrm <- subset(demo3verfRegular, lvl4==3)
write.csv(demo3verfRegularWrm, "3/3.1.1.3.csv")

#3.1.1.4 verified Regular HOT
demo3verfRegularHot <- subset(demo3verfRegular, lvl4==4)
write.csv(demo3verfRegularHot, "3/3.1.1.4.csv")



####### 2nd step 

#3.1.1.1.1 verified Regular FREEZE low
demo3verfRegularFrzLow <- subset(demo3verfRegularFrz, lvl5==1)
write.csv(demo3verfRegularFrzLow, "3/3.1.1.1.1.csv")

#3.1.1.1.2 verified Regular FREEZE mid-low
demo3verfRegularFrzMidLow <- subset(demo3verfRegularFrz, lvl5==2)
write.csv(demo3verfRegularFrzMidLow, "3/3.1.1.1.2.csv")

#3.1.1.1.3 verified Regular FREEZE mid-high
demo3verfRegularFrzHighMid <- subset(demo3verfRegularFrz, lvl5==3)
write.csv(demo3verfRegularFrzHighMid, "3/3.1.1.1.3.csv")

#3.1.1.1.4 verified Regular FREEZE high
demo3verfRegularFrzHigh <- subset(demo3verfRegularFrz, lvl5==4)
write.csv(demo3verfRegularFrzHigh, "3/3.1.1.1.4.csv")




#3.1.1.2.1 verified Regular COLD low
demo3verfRegularColdLow <- subset(demo3verfRegularCold, lvl5==1)
write.csv(demo3verfRegularColdLow, "3/3.1.1.2.1.csv")

#3.1.1.2.2 verified Regular COLD mid-low
demo3verfRegularColdMidLow <- subset(demo3verfRegularCold, lvl5==2)
write.csv(demo3verfRegularColdMidLow, "3/3.1.1.2.2.csv")

#3.1.1.2.3 verified Regular COLD high-mid
demo3verfRegularColdHighMid <- subset(demo3verfRegularCold, lvl5==3)
write.csv(demo3verfRegularColdHighMid, "3/3.1.1.2.3.csv")

#3.1.1.2.4 verified Regular COLD high
demo3verfRegularColdHigh <- subset(demo3verfRegularCold, lvl5==4)
write.csv(demo3verfRegularColdHigh, "3/3.1.1.2.4.csv")




#3.1.1.3.1 verified Regular WARM low
demo3verfRegularWrmLow <- subset(demo3verfRegularWrm, lvl5==1)
write.csv(demo3verfRegularWrmLow, "3/3.1.1.3.1.csv")

#3.1.1.3.2 verified Regular WARM mid-low
demo3verfRegularWrmMidLow <- subset(demo3verfRegularWrm, lvl5==2)
write.csv(demo3verfRegularWrmMidLow, "3/3.1.1.3.2.csv")

#3.1.1.3.3 verified Regular WARM high-mid
demo3verfRegularWrmHighMid <- subset(demo3verfRegularWrm, lvl5==3)
write.csv(demo3verfRegularWrmHighMid, "3/3.1.1.3.3.csv")

#3.1.1.3.4 verified Regular WARM high
demo3verfRegularWrmHigh <- subset(demo3verfRegularWrm, lvl5==4)
write.csv(demo3verfRegularWrmHigh, "3/3.1.1.3.4.csv")



#3.1.1.4.1 verified Regular HOT low
demo3verfRegularHotLow <- subset(demo3verfRegularHot, lvl5==1)
write.csv(demo3verfRegularHotLow, "3/3.1.1.4.1.csv")

#3.1.1.4.2 verified Regular HOT mid-low
demo3verfRegularHotMidLow <- subset(demo3verfRegularHot, lvl5==2)
write.csv(demo3verfRegularHotMidLow, "3/3.1.1.4.2.csv")

#3.1.1.4.3 verified Regular HOT high-mid
demo3verfRegularHotMidHighMid <- subset(demo3verfRegularHot, lvl5==3)
write.csv(demo3verfRegularHotMidHighMid, "3/3.1.1.4.3.csv")

#3.1.1.4.4 verified Regular HOT high
demo3verfRegularHotMidHigh <- subset(demo3verfRegularHot, lvl5==4)
write.csv(demo3verfRegularHotMidHigh, "3/3.1.1.4.4.csv")

