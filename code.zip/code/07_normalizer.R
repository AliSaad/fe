## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")

LearnerSegments <- read_csv("tmp/I.csv")
LearnerSegments <- LearnerSegments[,c("frequency", "learner_eng_ratio", "count_of_coursenroll", "count_of_certificates", "student_id")]
names(LearnerSegments)[2] <- "eng_ratio"


LearnerSegments$frequency <- as.numeric(LearnerSegments$frequency)
LearnerSegments$eng_ratio <- as.numeric(LearnerSegments$eng_ratio)
LearnerSegments$count_of_coursenroll <- as.numeric(LearnerSegments$count_of_coursenroll)
LearnerSegments$count_of_certificates <- as.numeric(LearnerSegments$count_of_certificates)

norm <- function(x){
      (x-min(x))/(max(x)-min(x))
}

LearnerSegments$count_of_coursenroll <- norm(as.numeric(LearnerSegments$count_of_coursenroll))
LearnerSegments$count_of_certificates <- norm(as.numeric(LearnerSegments$count_of_certificates))

max(LearnerSegments$recent_login)
max(LearnerSegments$recency)
max(LearnerSegments$frequency)
max(LearnerSegments$eng_ratio)
max(LearnerSegments$count_of_coursenroll)
max(LearnerSegments$count_of_certificates)


min(LearnerSegments$recent_login)
min(LearnerSegments$recency)
min(LearnerSegments$frequency)
min(LearnerSegments$eng_ratio)
min(LearnerSegments$count_of_coursenroll)
min(LearnerSegments$count_of_certificates)

###### save updates !
write.csv(LearnerSegments, "tmp/LearnerSegmen_after.csv")


certificatesmax=48
enrollmentsmax=74

