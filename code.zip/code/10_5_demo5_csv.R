library(readr)

demograph5 <- subset(xxi, lvl1==5)
write.csv(demograph5, "5/demograph5.csv")


#5.0 unverified
demo5unverf <- subset(demograph5, lvl2==0)
write.csv(demo5unverf, "5/5.0.csv")


#5.1 verified
demo5verf <- subset(demograph5, lvl2==1)
write.csv(demo5verf, "5/5.1.csv")



#5.0.0 unverified NEW
demo5unverfNew <- subset(demo5unverf, lvl3==0)
write.csv(demo5unverfNew, "5/5.0.0.csv")


#5.0.1 unverified Regular
demo5unverfRegular <- subset(demo5unverf, lvl3==1)
write.csv(demo5unverfRegular, "5/5.0.1.csv")



#5.1.0 verified NEW
demo5verfNew <- subset(demo5verf, lvl3==0)
write.csv(demo5verfNew, "5/5.1.0.csv")

#5.1.1 verified Regular
demo5verfRegular <- subset(demo5verf, lvl3==1)
write.csv(demo5verfRegular, "5/5.1.1.csv")



####### 1st step

#5.1.1.1 verified Regular FREEZE
demo5verfRegularFrz <- subset(demo5verfRegular, lvl4==1)
write.csv(demo5verfRegularFrz, "5/5.1.1.1.csv")

#5.1.1.2 verified Regular COLD
demo5verfRegularCold <- subset(demo5verfRegular, lvl4==2)
write.csv(demo5verfRegularCold, "5/5.1.1.2.csv")

#5.1.1.3 verified Regular WARM
demo5verfRegularWrm <- subset(demo5verfRegular, lvl4==3)
write.csv(demo5verfRegularWrm, "5/5.1.1.3.csv")

#5.1.1.4 verified Regular HOT
demo5verfRegularHot <- subset(demo5verfRegular, lvl4==4)
write.csv(demo5verfRegularHot, "5/5.1.1.4.csv")



####### 2nd step 

#5.1.1.1.1 verified Regular FREEZE low
demo5verfRegularFrzLow <- subset(demo5verfRegularFrz, lvl5==1)
write.csv(demo5verfRegularFrzLow, "5/5.1.1.1.1.csv")

#5.1.1.1.2 verified Regular FREEZE mid-low
demo5verfRegularFrzMidLow <- subset(demo5verfRegularFrz, lvl5==2)
write.csv(demo5verfRegularFrzMidLow, "5/5.1.1.1.2.csv")

#5.1.1.1.3 verified Regular FREEZE mid-high
demo5verfRegularFrzHighMid <- subset(demo5verfRegularFrz, lvl5==3)
write.csv(demo5verfRegularFrzHighMid, "5/5.1.1.1.3.csv")

#5.1.1.1.4 verified Regular FREEZE high
demo5verfRegularFrzHigh <- subset(demo5verfRegularFrz, lvl5==4)
write.csv(demo5verfRegularFrzHigh, "5/5.1.1.1.4.csv")




#5.1.1.2.1 verified Regular COLD low
demo5verfRegularColdLow <- subset(demo5verfRegularCold, lvl5==1)
write.csv(demo5verfRegularColdLow, "5/5.1.1.2.1.csv")

#5.1.1.2.2 verified Regular COLD mid-low
demo5verfRegularColdMidLow <- subset(demo5verfRegularCold, lvl5==2)
write.csv(demo5verfRegularColdMidLow, "5/5.1.1.2.2.csv")

#5.1.1.2.3 verified Regular COLD high-mid
demo5verfRegularColdHighMid <- subset(demo5verfRegularCold, lvl5==3)
write.csv(demo5verfRegularColdHighMid, "5/5.1.1.2.3.csv")

#5.1.1.2.4 verified Regular COLD high
demo5verfRegularColdHigh <- subset(demo5verfRegularCold, lvl5==4)
write.csv(demo5verfRegularColdHigh, "5/5.1.1.2.4.csv")




#5.1.1.3.1 verified Regular WARM low
demo5verfRegularWrmLow <- subset(demo5verfRegularWrm, lvl5==1)
write.csv(demo5verfRegularWrmLow, "5/5.1.1.3.1.csv")

#5.1.1.3.2 verified Regular WARM mid-low
demo5verfRegularWrmMidLow <- subset(demo5verfRegularWrm, lvl5==2)
write.csv(demo5verfRegularWrmMidLow, "5/5.1.1.3.2.csv")

#5.1.1.3.3 verified Regular WARM high-mid
demo5verfRegularWrmHighMid <- subset(demo5verfRegularWrm, lvl5==3)
write.csv(demo5verfRegularWrmHighMid, "5/5.1.1.3.3.csv")

#5.1.1.3.4 verified Regular WARM high
demo5verfRegularWrmHigh <- subset(demo5verfRegularWrm, lvl5==4)
write.csv(demo5verfRegularWrmHigh, "5/5.1.1.3.4.csv")



#5.1.1.4.1 verified Regular HOT low
demo5verfRegularHotLow <- subset(demo5verfRegularHot, lvl5==1)
write.csv(demo5verfRegularHotLow, "5/5.1.1.4.1.csv")

#5.1.1.4.2 verified Regular HOT mid-low
demo5verfRegularHotMidLow <- subset(demo5verfRegularHot, lvl5==2)
write.csv(demo5verfRegularHotMidLow, "5/5.1.1.4.2.csv")

#5.1.1.4.3 verified Regular HOT high-mid
demo5verfRegularHotMidHighMid <- subset(demo5verfRegularHot, lvl5==3)
write.csv(demo5verfRegularHotMidHighMid, "5/5.1.1.4.3.csv")

#5.1.1.4.4 verified Regular HOT high
demo5verfRegularHotMidHigh <- subset(demo5verfRegularHot, lvl5==4)
write.csv(demo5verfRegularHotMidHigh, "5/5.1.1.4.4.csv")

