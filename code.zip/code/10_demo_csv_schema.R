#output_files


#demographic 1
subset


#1.0 unverified
write.csv(, "output\1\1.0")


#1.1 verified
write.csv(, "output\1\1.1")



#1.0.0 unverified NEW
write.csv(, "output\1\1.0.0")


#1.0.1 unverified Regular
write.csv(, "output\1\1.0.1")



#1.1.0 verified NEW
write.csv(, "output\1\1.1.0")

#1.1.1 verified Regular
write.csv(, "output\1\1.1.1")



####### 1st step

#1.1.1.1 verified Regular FREEZE
write.csv(, "output\1\1.1.1.1")

#1.1.1.2 verified Regular COLD
write.csv(, "output\1\1.1.1.2")

#1.1.1.3 verified Regular WARM
write.csv(, "output\1\1.1.1.3")

#1.1.1.4 verified Regular HOT
write.csv(, "output\1\1.1.1.4")



####### 2nd step 

#1.1.1.1.1 verified Regular FREEZE low
write.csv(, "output\1\1.1.1.1.1")

#1.1.1.1.2 verified Regular FREEZE mid-low
write.csv(, "output\1\1.1.1.1.2")

#1.1.1.1.3 verified Regular FREEZE mid-high
write.csv(, "output\1\1.1.1.1.3")

#1.1.1.1.4 verified Regular FREEZE high
write.csv(, "output\1\1.1.1.1.4")




#1.1.1.2.1 verified Regular COLD low
write.csv(, "output\1\1.1.1.2.1")

#1.1.1.2.2 verified Regular COLD mid-low
write.csv(, "output\1\1.1.1.2.2")

#1.1.1.2.3 verified Regular COLD high-mid
write.csv(, "output\1\1.1.1.2.3")

#1.1.1.2.4 verified Regular COLD high
write.csv(, "output\1\1.1.1.2.4")




#1.1.1.3.1 verified Regular WARM low
write.csv(, "output\1\1.1.1.3.1")

#1.1.1.3.2 verified Regular WARM mid-low
write.csv(, "output\1\1.1.1.3.2")

#1.1.1.3.3 verified Regular WARM high-mid
write.csv(, "output\1\1.1.1.3.3")

#1.1.1.3.4 verified Regular WARM high
write.csv(, "output\1\1.1.1.3.4")



#1.1.1.4.1 verified Regular HOT low
write.csv(, "output\1\1.1.1.4.1")

#1.1.1.4.2 verified Regular HOT mid-low
write.csv(, "output\1\1.1.1.4.2")

#1.1.1.4.3 verified Regular HOT high-mid
write.csv(, "output\1\1.1.1.4.3")

#1.1.1.4.4 verified Regular HOT high
write.csv(, "output\1\1.1.1.4.4")
