## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")

#Input file should contain age_group vector !
ds <- read_csv("tmp/ds.csv")
wrk <- ds


###### level_of_education ##########
loe <-  wrk$level_of_education
loe <- as.character(loe)

loe <- factor(loe,
              levels = c("none", "el", "p", "jhs", "hs", "b", "a", "m", "d"),
              labels = c("1", "0.8571429", "0.8571429", "0.7142857", "0.5714286", "0.4285714", "0.2857143", "0.1428571", "0"))

wrk <- cbind(wrk, loe)
wrk <- subset(wrk,!(is.na(wrk["loe"])))

write.csv(wrk, "tmp/0.2_elmagic.csv")

########### gender ##############
gndr <- wrk$gender
gndr <-as.character(gndr)

gndr <- factor(gndr,
               levels = c("m", "f"),
               labels = c("1", "0"))

wrk <- cbind(wrk, gndr)
write.csv(wrk, "tmp/0.3_elmagic.csv")

########### Refugees ###########
refugees <- wrk$country
refugees <- factor(refugees,
                   levels = c("SY", "TR", "YE", "PS", "IQ", "LY"),
                   labels = c("13", "13", "13", "13", "13", "13"))

write.csv(refugees, "tmp/tmp_refugees.csv")
refugees <- read_csv("tmp/tmp_refugees.csv")
refugees <- as.data.frame(refugees)
refugees[is.na(refugees)] <- 7

wrk <- cbind(wrk, refugees)
write.csv(wrk, "tmp/0.4_elmagic.csv")

############# Age Groups ##############
age_ncategory = wrk$SelectedCountries.year_of_birth
age_ncategory <- factor(age_ncategory,
                        levels = c('Under 18', '18 to 24', '25 to 34', '35 to 44', 'Over 44'),
                        labels = c("1", "0.75", "0.5", "0.25", "0"))

wrk <- cbind(wrk, age_ncategory)
write.csv(wrk, "tmp/elmagic.csv")


######
rm(ds, wrk, loe, gndr, refugees, age_ncategory)
