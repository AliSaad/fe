## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")


mktcours <- read_csv("dataset/mktcours.csv")
mktcours <- mktcours[!is.na(mktcours$course_description_en),]

#qrta1 <- mktcours[grepl("course-v1:QRTA+TLC100+TLC_SP2015", mktcours$id),]
#qrta2 <- mktcours[grepl("course-v1:QRTA+BATT_M1+2016_M1", mktcours$id),]
qrta1 <- subset(mktcours, id=="course-v1:QRTA+TLC100+TLC_SP2015")
qrta2 <- subset(mktcours, id=="course-v1:QRTA+BATT_M1+2016_M1")

mktcours <- mktcours[!grepl("GJU", mktcours$id),]
mktcours <- mktcours[!grepl("QRTA", mktcours$id),]

mktcours <- rbind(mktcours, qrta1, qrta2)

if(!require(lubridate)){install.packages("lubridate")}
if(!require(lubridate)){install.packages("lubridate")}
pdt <- parse_date_time(mktcours$start_date, "ymd_HMS")
pdt <- parse_date_time(mktcours$end_date, "ymd_HMS")


if(!require(plyr)){install.packages("plyr")}
if(!require(plyr)){install.packages("plyr")}
if(!require(dplyr)){install.packages("dplyr")}
if(!require(dplyr)){install.packages("dplyr")}

courses <- mktcours
start_date_nas <- courses[is.na(courses$start_date),]
courses$start_date <- as.POSIXlt(courses$start_date)
today <- as.POSIXlt(Sys.Date())
date1 <- today
date1$mday <- date1$mday + 45
date2 <- date1
date2$mday <- date1$mday - 546
start_courses <- courses[courses$start_date <= date1 & courses$start_date >= date2, ]




courses <- mktcours
end_date_nas <- courses[is.na(courses$end_date),]
courses <- courses[!(is.na(courses$end_date)),]

courses$end_date <- as.POSIXlt(courses$end_date)
today <- as.POSIXlt(Sys.Date())
date1 <- today
date1$mday <- date1$mday + 45
date2 <- date1
date2$mday <- date1$mday - 546
end_courses <- courses[courses$end_date >= date2, ]

courses <- rbind(start_courses, end_date_nas, end_courses, start_date_nas)
courses <- courses[!duplicated(courses[,"id"]),]

rm(mktcours, pdt, DATA, date, nn, date1, date2, today, start_courses, end_courses, start_date_nas, end_date_nas, qrta1, qrta2)
write.csv(courses, "tmp/courses.csv")
rm(courses)

if("package:readr" %in% search()) detach("package:readr", unload=TRUE)
if("package:lubridate" %in% search()) detach("package:lubridate", unload=TRUE) 
if("package:plyr" %in% search()) detach("package:plyr", unload=TRUE) 
if("package:dplyr" %in% search()) detach("package:dplyr", unload=TRUE) 
