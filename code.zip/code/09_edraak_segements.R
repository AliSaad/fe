#get_data #1st step
## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")
learners_vaues <- read_csv("tmp/learner_clusters.csv")

## Before final files
########### status (lvl3) ##############

xxi <- learners_vaues
xxi$recency <- NULL
satus = xxi$is_active
satus <-as.character(satus)

satus <- factor(satus,
                levels = c("new comers", "regular"),
                labels = c("0", "1"))



########### recency ##############
recency = xxi$nn_weeks
irecency = cut(as.table(as.numeric(recency)), c(1, -6.01, -26.01, -52.01, -1040.01),
               include.lowest = TRUE,
               labels = c("Hot", "Warm", "Cold", "Freeze"))

recency <- factor(irecency,
                  levels = c("Hot", "Warm", "Cold", "Freeze"),
                  labels = c("4", "3", "2", "1"))

########## end ####

lvl1 <- xxi$labels
lvl2 <- xxi$is_active
lvl3 <- satus
lvl4 <- recency
lvl5 <- xxi$value

xxi <- cbind(xxi, lvl1, lvl2, lvl3, lvl4, lvl5)
yield <- paste(xxi$lvl1,".",xxi$lvl2,".",
               xxi$lvl3,".", xxi$lvl4,".", xxi$lvl5)

xxi <- cbind(xxi, yield)
write.csv(xxi, "yield/Edraak_segments.csv")


