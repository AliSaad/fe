i <- read.csv("dataset/01_auth_userprofile.csv")

# clean data (remove NAs and blank rows)
i <- i[!(is.na(i$user_id) | i$user_id==""), ]
i <- i[!(is.na(i$gender) | i$gender==""), ]
i <- i[!(is.na(i$year_of_birth) | i$year_of_birth==""), ]
i <- i[!(is.na(i$level_of_education) | i$level_of_education==""), ]
i <- i[!(is.na(i$country) | i$country==""), ]

Data.features <- i


indx <- 2017 - as.numeric(Data.features$year_of_birth)
Data.features$age_group <- cut(indx, breaks=c(0,3,17.5,24.5,34.5,44.5,90,Inf),
                               labels=c('Unknown', 'Under 18', '18 to 24', '25 to 34', '35 to 44', 'Over 44', 'Unknown') )
write.csv(Data.features, "tmp/tmp/dta_feature.csv")
rm(i, indx, Data.features)
Data.features <- read.csv("tmp/dta_feature.csv")


#### clust3m4f <<- clust3 == mean cluster three, m == level of education, 4 == age group, f == gender
## clus1 ####
clust1m <- subset(Data.features, age_group == "18 to 24" & level_of_education != "m")
clust1b <- subset(Data.features, age_group == "18 to 24" & level_of_education != "b")
clust1d <- subset(Data.features, age_group == "18 to 24" & level_of_education != "d")

clust1 <- rbind(clust1m, clust1b, clust1d)
rm(clust1m, clust1b, clust1d)


## clus2 ####
clut2m4 <- subset(Data.features, age_group == "25 to 34" & level_of_education != "m" & gender == "f")
clut2m5 <- subset(Data.features, age_group == "35 to 44" & level_of_education != "m" & gender == "f")

clut2 <- rbind(clut2m4, clut2m5)
rm(clut2m4, clut2m5)


## clust3 ####
clust3hs4m <- subset(Data.features, age_group == "25 to 34" & gender == "m" & level_of_education != "hs")
clust3hs5m <- subset(Data.features, age_group == "35 to 44" & gender == "m" & level_of_education != "hs")
clust3hsm <- rbind(clust3hs4m, clust3hs5m)
rm(clust3hs4m, clust3hs5m)

clust3jhs4m <- subset(Data.features, age_group == "25 to 34" & gender == "m" & level_of_education != "jhs")
clust3jhs5m <- subset(Data.features, age_group == "35 to 44" & gender == "m" & level_of_education != "jhs")
clust3jhsm <- rbind(clust3jhs4m, clust3jhs5m)
rm(clust3jhs4m, clust3jhs5m)

clust3m4f <- subset(Data.features, age_group == "25 to 34" & gender == "f" & level_of_education == "m")
clust3m5f <- subset(Data.features, age_group == "35 to 44" & gender == "f" & level_of_education == "m")
clust3mf <- rbind(clust3m4f, clust3m5f)
rm(clust3m4f, clust3m5f)

clust3 <- rbind(clust3hsm, clust3jhsm, clust3mf)
rm(clust3hsm, clust3jhsm, clust3mf)


## clust4 ####
##### clust 'Number' 'COUNTRY' 'CATG' 'LOE' 'AGEGROUP'
clust4sy9b3 <- subset(Data.features, age_group == "25 to 34" & country == "SY" & level_of_education == "b")
clust4tr9b3 <- subset(Data.features, age_group == "25 to 34" & country == "TR" & level_of_education == "b")
clust4ye9b3 <- subset(Data.features, age_group == "25 to 34" & country == "YE" & level_of_education == "b")
clust4ps9b3 <- subset(Data.features, age_group == "25 to 34" & country == "PS" & level_of_education == "b")
clust4iq9b3 <- subset(Data.features, age_group == "25 to 34" & country == "IQ" & level_of_education == "b")
clust4ly9b3 <- subset(Data.features, age_group == "25 to 34" & country == "LY" & level_of_education == "b")
samp4p1 <- rbind(clust4sy9b3, clust4tr9b3, clust4ye9b3, clust4ps9b3, clust4iq9b3, clust4ly9b3)
rm(clust4sy9b3, clust4tr9b3, clust4ye9b3, clust4ps9b3, clust4iq9b3, clust4ly9b3)

clust4sy9b4 <- subset(Data.features, age_group == "35 to 44" & country == "SY" & level_of_education == "b")
clust4tr9b4 <- subset(Data.features, age_group == "35 to 44" & country == "TR" & level_of_education == "b")
clust4ye9b4 <- subset(Data.features, age_group == "35 to 44" & country == "YE" & level_of_education == "b")
clust4ps9b4 <- subset(Data.features, age_group == "35 to 44" & country == "PS" & level_of_education == "b")
clust4iq9b4 <- subset(Data.features, age_group == "35 to 44" & country == "IQ" & level_of_education == "b")
clust4ly9b4 <- subset(Data.features, age_group == "35 to 44" & country == "LY" & level_of_education == "b")
samp4p4 <- rbind(clust4sy9b4, clust4tr9b4, clust4ye9b4, clust4ps9b4, clust4iq9b4, clust4ly9b4)
rm(clust4sy9b4, clust4tr9b4, clust4ye9b4, clust4ps9b4, clust4iq9b4, clust4ly9b4)

clust4sy9hs4 <- subset(Data.features, age_group == "35 to 44" & country == "SY" & level_of_education == "hs")
clust4tr9hs4 <- subset(Data.features, age_group == "35 to 44" & country == "TR" & level_of_education == "hs")
clust4ye9hs4 <- subset(Data.features, age_group == "35 to 44" & country == "YE" & level_of_education == "hs")
clust4ps9hs4 <- subset(Data.features, age_group == "35 to 44" & country == "PS" & level_of_education == "hs")
clust4iq9hs4 <- subset(Data.features, age_group == "35 to 44" & country == "IQ" & level_of_education == "hs")
clust4ly9hs4 <- subset(Data.features, age_group == "35 to 44" & country == "LY" & level_of_education == "hs")
samp4p7 <- rbind(clust4sy9hs4, clust4tr9hs4, clust4ye9hs4, clust4ps9hs4, clust4iq9hs4, clust4ly9hs4)
rm(clust4sy9hs4, clust4tr9hs4, clust4ye9hs4, clust4ps9hs4, clust4iq9hs4, clust4ly9hs4)

clust4sy1hs3 <- subset(Data.features, age_group == "25 to 34" & country == "SY" & level_of_education == "hs")
clust4tr1hs3 <- subset(Data.features, age_group == "25 to 34" & country == "TR" & level_of_education == "hs")
clust4ye1hs3 <- subset(Data.features, age_group == "25 to 34" & country == "YE" & level_of_education == "hs")
clust4ps1hs3 <- subset(Data.features, age_group == "25 to 34" & country == "PS" & level_of_education == "hs")
clust4iq1hs3 <- subset(Data.features, age_group == "25 to 34" & country == "IQ" & level_of_education == "hs")
clust4ly1hs3 <- subset(Data.features, age_group == "25 to 34" & country == "LY" & level_of_education == "hs")
samp4p12 <- rbind(clust4sy1hs3, clust4tr1hs3, clust4ye1hs3, clust4ps1hs3, clust4iq1hs3, clust4ly1hs3)
rm(clust4sy1hs3, clust4tr1hs3, clust4ye1hs3, clust4ps1hs3, clust4iq1hs3, clust4ly1hs3)

clust4sy9jhs4 <- subset(Data.features, age_group == "35 to 44" & country == "SY" & level_of_education == "jhs")
clust4tr9jhs4 <- subset(Data.features, age_group == "35 to 44" & country == "TR" & level_of_education == "jhs")
clust4ye9jhs4 <- subset(Data.features, age_group == "35 to 44" & country == "YE" & level_of_education == "jhs")
clust4ps9jhs4 <- subset(Data.features, age_group == "35 to 44" & country == "PS" & level_of_education == "jhs")
clust4iq9jhs4 <- subset(Data.features, age_group == "35 to 44" & country == "IQ" & level_of_education == "jhs")
clust4ly9jhs4 <- subset(Data.features, age_group == "35 to 44" & country == "LY" & level_of_education == "jhs")
samp4p13 <- rbind(clust4sy9jhs4, clust4tr9jhs4, clust4ye9jhs4, clust4ps9jhs4, clust4iq9jhs4, clust4ly9jhs4)
rm(clust4sy9jhs4, clust4tr9jhs4, clust4ye9jhs4, clust4ps9jhs4, clust4iq9jhs4, clust4ly9jhs4)

clust4sy9jhs3 <- subset(Data.features, age_group == "25 to 34" & country == "SY" & level_of_education == "jhs")
clust4tr9jhs3 <- subset(Data.features, age_group == "25 to 34" & country == "TR" & level_of_education == "jhs")
clust4ye9jhs3 <- subset(Data.features, age_group == "25 to 34" & country == "YE" & level_of_education == "jhs")
clust4ps9jhs3 <- subset(Data.features, age_group == "25 to 34" & country == "PS" & level_of_education == "jhs")
clust4iq9jhs3 <- subset(Data.features, age_group == "25 to 34" & country == "IQ" & level_of_education == "jhs")
clust4ly9jhs3 <- subset(Data.features, age_group == "25 to 34" & country == "LY" & level_of_education == "jhs")
samp4p16 <- rbind(clust4sy9jhs3, clust4tr9jhs3, clust4ye9jhs3, clust4ps9jhs3, clust4iq9jhs3, clust4ly9jhs3)
rm(clust4sy9jhs3, clust4tr9jhs3, clust4ye9jhs3, clust4ps9jhs3, clust4iq9jhs3, clust4ly9jhs3)


clust4 <- rbind(samp4p1, samp4p4, samp4p7, samp4p12, samp4p13, samp4p16)
rm(samp4p1, samp4p4, samp4p7, samp4p12, samp4p13, samp4p16)


## clust5 ####
clust5hs4 <- subset(Data.features, age_group == "25 to 34" & level_of_education == "hs")
clust5hs5 <- subset(Data.features, age_group == "35 to 44" & level_of_education == "hs")
clust5hs6 <- subset(Data.features, age_group == "Over 44" & level_of_education == "hs")
clust5jhs4 <- subset(Data.features, age_group == "25 to 34" & level_of_education == "jhs")
clust5jhs5 <- subset(Data.features, age_group == "35 to 44" & level_of_education == "jhs")
clust5jhs6 <- subset(Data.features, age_group == "Over 44" & level_of_education == "jhs")

clust5 <- rbind(clust5hs4, clust5hs5, clust5hs6, clust5jhs4, clust5jhs5, clust5jhs6)
rm(clust5 <- rbind(clust5hs4, clust5hs5, clust5hs6, clust5jhs4, clust5jhs5, clust5jhs6))




#### Add labels ####
clust1$labels <- 1
clust2$labels <- 2
clust3$labels <- 3
clust4$labels <- 4
clust5$labels <- 5


clust1 <- clust1[!duplicated(clust1[,"user_id"]),]
clust2 <- clust2[!duplicated(clust2[,"user_id"]),]
clust3 <- clust3[!duplicated(clust3[,"user_id"]),]
clust4 <- clust4[!duplicated(clust4[,"user_id"]),]
clust5 <- clust5[!duplicated(clust5[,"user_id"]),]


### done.. save ####
LearnerSegments <- rbind(clust4, clust5, clust1, clust2, clust3)
LearnerSegments <- LearnerSegments[!duplicated(LearnerSegments[,"user_id"]),]
write.csv(LearnerSegments, "tmp/LearnerSegments.csv")
rm(clust4, clust5, clust1, clust2, clust3)
rm(Data.features, LearnerSegments)


