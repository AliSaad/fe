#get_data #1st step
## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")

auth_userprofile <- read_csv("tmp/LearnerSegments.csv")
auth_userprofile <- auth_userprofile[,c("user_id", "name", "gender",
                                        "mailing_address", "year_of_birth",  "country",
                                        "level_of_education", "goals")]

if(!require(dplyr)){install.packages("dplyr")}
if(!require(dplyr)){install.packages("dplyr")}
if(!require(data.table)){install.packages("data.table")}
if(!require(data.table)){install.packages("data.table")}
isPackageLoaded("dplyr")
isPackageLoaded("data.table")


shaml <- auth_userprofile

auth_user <- read_csv("dataset/02_auth_user.csv")
excepted1 <- subset(auth_user, is_staff==1)
excepted2 <- subset(auth_user, is_superuser==1)
supers <- rbind(excepted1, excepted2)
supers <- supers[!duplicated(supers[,"id"]),]

auth_user <- subset(auth_user, is_staff==0)
auth_user <- subset(auth_user, is_superuser==0)
auth_user <- auth_user[,c("id", "username", "first_name", "last_name",
                          "email", "is_staff", "is_active", "is_superuser",
                          "last_login", "date_joined")]

names(auth_user)[1] <- "user_id"

auth_user$user_id <- as.factor(auth_user$user_id)
      shaml$user_id <- as.factor(shaml$user_id)
shamlx <- merge(shaml, auth_user, by = "user_id", all = TRUE)

'%!in%' <- function(x,y)!('%in%'(x,y))
learners <- subset(shamlx, user_id %!in% supers$id)
write.csv(learners, "tmp/learners.csv")


#Between learners.csv and rfenn.csv
ids <- read_csv("tmp/learners.csv")
rfecc <- read_csv("rfecc.csv")
ds <- full_join(ids, rfecc, by = c("user_id" = "student_id"))
write.csv(ds, "tmp/ds.csv")
rm(auth_userprofile, shaml, auth_user, excepted1, excepted2, supers, auth_user, learners, ids, rfecc)




