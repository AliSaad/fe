#### read grades files ####
# read multiple files and add "Source" vector contain file name for each row

#set dir to grades dir

if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(plyr)){install.packages("plyr")}
if(!require(plyr)){install.packages("plyr")}
if(!require(dplyr)){install.packages("dplyr")}
if(!require(dplyr)){install.packages("dplyr")}
isPackageLoaded("plyr")
isPackageLoaded("dplyr")

homedir <- getwd()
cert <- "dataset/certificates"
setwd(cert)

read_csv_filename <- function(filename){
      ret <- read.csv(filename)
      ret$Source <- filename #EDIT
      ret
}

files = list.files(path = ".", pattern="*.csv",all.files = TRUE)
filenames <- list.files(path = ".", pattern = NULL, all.files = FALSE, full.names = FALSE, recursive = FALSE, ignore.case = FALSE)
grades <- ldply(files, read_csv_filename)
grades <- grades[,c("id", "email", "username", "grade", "Source", "Certificate.Eligible")]

rm(read_csv_filename, files, filenames)

setwd(homedir)
write.csv(grades, "dataset/grades.csv")
##### Done | read grades files
