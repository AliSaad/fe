library(readr)

demograph4 <- subset(xxi, lvl1==4)
write.csv(demograph4, "4/demograph4.csv")


#4.0 unverified
demo4unverf <- subset(demograph4, lvl2==0)
write.csv(demo4unverf, "4/4.0.csv")


#4.1 verified
demo4verf <- subset(demograph4, lvl2==1)
write.csv(demo4verf, "4/4.1.csv")



#4.0.0 unverified NEW
demo4unverfNew <- subset(demo4unverf, lvl3==0)
write.csv(demo4unverfNew, "4/4.0.0.csv")


#4.0.1 unverified Regular
demo4unverfRegular <- subset(demo4unverf, lvl3==1)
write.csv(demo4unverfRegular, "4/4.0.1.csv")



#4.1.0 verified NEW
demo4verfNew <- subset(demo4verf, lvl3==0)
write.csv(demo4verfNew, "4/4.1.0.csv")

#4.1.1 verified Regular
demo4verfRegular <- subset(demo4verf, lvl3==1)
write.csv(demo4verfRegular, "4/4.1.1.csv")



####### 1st step

#4.1.1.1 verified Regular FREEZE
demo4verfRegularFrz <- subset(demo4verfRegular, lvl4==1)
write.csv(demo4verfRegularFrz, "4/4.1.1.1.csv")

#4.1.1.2 verified Regular COLD
demo4verfRegularCold <- subset(demo4verfRegular, lvl4==2)
write.csv(demo4verfRegularCold, "4/4.1.1.2.csv")

#4.1.1.3 verified Regular WARM
demo4verfRegularWrm <- subset(demo4verfRegular, lvl4==3)
write.csv(demo4verfRegularWrm, "4/4.1.1.3.csv")

#4.1.1.4 verified Regular HOT
demo4verfRegularHot <- subset(demo4verfRegular, lvl4==4)
write.csv(demo4verfRegularHot, "4/4.1.1.4.csv")



####### 2nd step 

#4.1.1.1.1 verified Regular FREEZE low
demo4verfRegularFrzLow <- subset(demo4verfRegularFrz, lvl5==1)
write.csv(demo4verfRegularFrzLow, "4/4.1.1.1.1.csv")

#4.1.1.1.2 verified Regular FREEZE mid-low
demo4verfRegularFrzMidLow <- subset(demo4verfRegularFrz, lvl5==2)
write.csv(demo4verfRegularFrzMidLow, "4/4.1.1.1.2.csv")

#4.1.1.1.3 verified Regular FREEZE mid-high
demo4verfRegularFrzHighMid <- subset(demo4verfRegularFrz, lvl5==3)
write.csv(demo4verfRegularFrzHighMid, "4/4.1.1.1.3.csv")

#4.1.1.1.4 verified Regular FREEZE high
demo4verfRegularFrzHigh <- subset(demo4verfRegularFrz, lvl5==4)
write.csv(demo4verfRegularFrzHigh, "4/4.1.1.1.4.csv")




#4.1.1.2.1 verified Regular COLD low
demo4verfRegularColdLow <- subset(demo4verfRegularCold, lvl5==1)
write.csv(demo4verfRegularColdLow, "4/4.1.1.2.1.csv")

#4.1.1.2.2 verified Regular COLD mid-low
demo4verfRegularColdMidLow <- subset(demo4verfRegularCold, lvl5==2)
write.csv(demo4verfRegularColdMidLow, "4/4.1.1.2.2.csv")

#4.1.1.2.3 verified Regular COLD high-mid
demo4verfRegularColdHighMid <- subset(demo4verfRegularCold, lvl5==3)
write.csv(demo4verfRegularColdHighMid, "4/4.1.1.2.3.csv")

#4.1.1.2.4 verified Regular COLD high
demo4verfRegularColdHigh <- subset(demo4verfRegularCold, lvl5==4)
write.csv(demo4verfRegularColdHigh, "4/4.1.1.2.4.csv")




#4.1.1.3.1 verified Regular WARM low
demo4verfRegularWrmLow <- subset(demo4verfRegularWrm, lvl5==1)
write.csv(demo4verfRegularWrmLow, "4/4.1.1.3.1.csv")

#4.1.1.3.2 verified Regular WARM mid-low
demo4verfRegularWrmMidLow <- subset(demo4verfRegularWrm, lvl5==2)
write.csv(demo4verfRegularWrmMidLow, "4/4.1.1.3.2.csv")

#4.1.1.3.3 verified Regular WARM high-mid
demo4verfRegularWrmHighMid <- subset(demo4verfRegularWrm, lvl5==3)
write.csv(demo4verfRegularWrmHighMid, "4/4.1.1.3.3.csv")

#4.1.1.3.4 verified Regular WARM high
demo4verfRegularWrmHigh <- subset(demo4verfRegularWrm, lvl5==4)
write.csv(demo4verfRegularWrmHigh, "4/4.1.1.3.4.csv")



#4.1.1.4.1 verified Regular HOT low
demo4verfRegularHotLow <- subset(demo4verfRegularHot, lvl5==1)
write.csv(demo4verfRegularHotLow, "4/4.1.1.4.1.csv")

#4.1.1.4.2 verified Regular HOT mid-low
demo4verfRegularHotMidLow <- subset(demo4verfRegularHot, lvl5==2)
write.csv(demo4verfRegularHotMidLow, "4/4.1.1.4.2.csv")

#4.1.1.4.3 verified Regular HOT high-mid
demo4verfRegularHotMidHighMid <- subset(demo4verfRegularHot, lvl5==3)
write.csv(demo4verfRegularHotMidHighMid, "4/4.1.1.4.3.csv")

#4.1.1.4.4 verified Regular HOT high
demo4verfRegularHotMidHigh <- subset(demo4verfRegularHot, lvl5==4)
write.csv(demo4verfRegularHotMidHigh, "4/4.1.1.4.4.csv")

