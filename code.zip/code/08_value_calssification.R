## required packages
if(!require(R.utils)){install.packages("R.utils")}
if(!require(R.utils)){install.packages("R.utils")}
if(!require(readr)){install.packages("readr")}
if(!require(readr)){install.packages("readr")}

# chk pkgs loaded successfully
isPackageLoaded("R.utils")
isPackageLoaded("readr")

train <- read_csv("dataset/ssPreDist.csv")
ds <- read_csv("tmp/LearnerSegmen_after.csv")

train <- data1[,c("frequency", "eng_ratio", "count_of_coursenroll", "count_of_certificates", "class")]
ds <- data3[,c("frequency", "eng_ratio", "count_of_coursenroll", "count_of_certificates")]
ds$class <- 0

sub <- c(sample(1:10000, 5000), sample(10000:20000, 5000), 
         sample(20000:28000, 4000))
datasets001 <- as.data.frame(train)
datasets001$class <- as.factor(datasets001$class)

data.bagging <- bagging(class ~ ., data=datasets001[sub,], mfinal=1200)
data1.predbagging <- predict.bagging(data.bagging, newdata=datasets001[,], newmfinal = 500)

train$class <- NULL
step1 <- cbind(train, data1.predbagging$class)
names(step1)[5] <- "class"

step2 <- rbind(step1, ds)

sub <- c(sample(1:nrow(step1), nrow(step1)))

datasets002 <- as.data.frame(step2)
datasets002$class <- as.factor(datasets002$class)

data2.bagging <- bagging(class ~ ., data=datasets002[sub,], mfinal=1200)
data2.predbagging <- predict.bagging(data2.bagging, newdata=datasets002[,], newmfinal = 500)

step2$class <- NULL
learner_values <- cbind(step2, data2.predbagging$class)
names(learner_values)[5] <- "value"

learner_values <- learner_values[-1:nrow(step1),]

write.csv("tmp/learner_values.csv")


learners <- read_csv("tmp/I.csv")
learners_values <- read_csv("tmp/learner_values.csv")

learner-clusters <- cbind(learners, learners_values$value)
write.csv("tmp/learner_clusters.csv")
